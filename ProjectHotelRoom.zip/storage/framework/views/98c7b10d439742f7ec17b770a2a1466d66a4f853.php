

<?php $__env->startSection('title', 'Trang dịch vụ'); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admins/main.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-container container-fluid px-4">
<?php echo $__env->make('admin.partials.title-content', ['name'=>'Trang dịch vụ'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<div class="row">
    <div class="col">
      <div class="card card-small mb-4">
        <div class="card-header border-bottom">
          <h6 class="m-0">Thêm dịch vụ</h6>
          <a class="nav-link " href="<?php echo e(route('services.add')); ?>">
            <i class="material-icons">note_add</i>
            <span>Thêm dịch vụ</span>
          </a>

        </div>
        <div class="card-body p-0 pb-3 text-center">
          <table class="table mb-0">
            <thead class="bg-light">
              <tr>
                <th scope="col" class="border-0">#</th>
                <th scope="col" class="border-0">Tên dịch vụ</th>
                <th scope="col" class="border-0">Icon</th> 
                <th scope="col" class="border-0">Action</th>
              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($service->id); ?></td>
                  <td><?php echo e($service->name); ?></td>
                  <td><img width="200" height="200" src="<?php echo e(asset($service->icon)); ?>" alt="Lỗi"></td>
                  <td>
                    <a href="<?php echo e(route('services.edit', ['id' =>$service->id])); ?>" class="mb-2 btn btn-info mr-2 ">Sửa</a>
                    <a href="" data-url="<?php echo e(route('services.delete', ['id' => $service->id])); ?>" class="mb-2 btn btn-danger mr-2 action_delete">Xóa</a>
                  </td>
                </tr>
              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
            </tbody>
          </table>

        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ProjectHotelRoom\resources\views/admin/services/index.blade.php ENDPATH**/ ?>